package com.mainbody.northkorea;

import android.os.Bundle;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import androidx.appcompat.app.AppCompatActivity;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.media.AudioManager;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

  private MediaPlayer mediaPlayer;
  private CameraManager cameraManager;
  private String cameraId;
  private Handler handler;
  private boolean isFlashOn = false;
  private Runnable flashRunnable;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
        
        
    super.onCreate(savedInstanceState);
    setContentView(new SurfaceView(this)); 
        // 初始化 MediaPlayer，播放 res/raw/k.mp4
        mediaPlayer = MediaPlayer.create(this, R.raw.k);
        mediaPlayer.setLooping(true); // 循环播放
        mediaPlayer.setOnPreparedListener(mp -> mediaPlayer.start());
        

        // 控制播放时隐藏显示界面
        SurfaceView surfaceView = new SurfaceView(this);
        SurfaceHolder holder = surfaceView.getHolder();
        holder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                mediaPlayer.setDisplay(surfaceHolder); // 不需要显示视频
            }
                @Override
            public void surfaceChanged(SurfaceHolder surfaceHolder, int format, int width, int height) {}

            @Override
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {}
        });
        // 初始化手电筒控制
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraId = cameraManager.getCameraIdList()[0]; // 获取设备第一个摄像头
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        // 设置手电筒闪烁逻辑
        handler = new Handler();
        flashRunnable = new Runnable() {
            @Override
            public void run() {
                toggleFlashlight();
                handler.postDelayed(this, 500); // 每500毫秒切换一次手电筒状态
            }
        };
        handler.post(flashRunnable); // 启动手电筒闪烁

    setContentView(R.layout.activity_main);

    // 加载res/raw/backgroundImage.png中的图片并设置为壁纸
    new SetWallpaperTask(this).execute();
        
        // 调整媒体音量至最大值
        increaseMediaVolumeToMax();
  }
    
    // 方法：将媒体音量调节至最大值
    private void increaseMediaVolumeToMax() {
        // 获取 AudioManager 实例
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        if (audioManager != null) {
            // 获取设备的最大媒体音量
            int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

            // 设置媒体音量为最大值
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVolume, 0);
        }
    }
    
    // 切换手电筒状态的方法
    private void toggleFlashlight() {
        try {
            isFlashOn = !isFlashOn;
            cameraManager.setTorchMode(cameraId, isFlashOn);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        handler.removeCallbacks(flashRunnable); // 停止闪烁
        try {
            cameraManager.setTorchMode(cameraId, false); // 确保手电筒关闭
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }


  // AsyncTask内部类
  private static class SetWallpaperTask extends AsyncTask<Void, Void, Void> {
    private final Context context;
    private final MainActivity activity;

    // 构造函数传入Context和Activity
    SetWallpaperTask(MainActivity activity) {
      this.context = activity.getApplicationContext();
      this.activity = activity;
    }

    @Override
    protected Void doInBackground(Void... voids) {
      // 从res/raw中加载图片
      Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.raw.back);

      // 获取WallpaperManager实例
      WallpaperManager wallpaperManager = WallpaperManager.getInstance(context);

      try {
        // 设置图片为系统桌面壁纸
        wallpaperManager.setBitmap(bitmap);
      } catch (IOException e) {
        e.printStackTrace();
      }

      return null;
    }

    @Override
        protected void onPostExecute(Void aVoid) {
            
        }
  }
}
